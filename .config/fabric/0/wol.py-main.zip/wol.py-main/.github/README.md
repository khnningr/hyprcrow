# Wol.py
## This is currently in Working Progress
### Updates are slow since I'm stu'dying' for my degree...
- my archlinux dotfiles using Hyprland and Fabric

### Themes

#### Creme (Light)
![image](creme.png)

#### Coffee (Dark)
![image](coffee.png)
