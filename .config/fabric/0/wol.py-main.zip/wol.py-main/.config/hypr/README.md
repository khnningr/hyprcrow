hyprland confs
